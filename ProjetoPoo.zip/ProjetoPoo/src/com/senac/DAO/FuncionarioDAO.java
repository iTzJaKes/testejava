package com.senac.DAO;

import com.senac.interfaces.DAO;
import com.senac.modelos.Funcionario;
import com.senac.modelos.Produto;

public class FuncionarioDAO implements DAO<Funcionario>{
	private String TABELA_NOME = "funcionario";
	
	@Override
	public String listar() {
		String sql = "SELECT * FROM "+TABELA_NOME+" "
				+ "ORDER BY id DESC";
		return sql;
	}

	@Override
	public String cadastrar(Funcionario obj) {
		String sql = "INSERT INTO " + TABELA_NOME + "(nome, cpf, dtnasc) "
				+ "VALUES ("
				+ "'"+obj.getNome()+"',"
				+ obj.getCpf()+", "
				+ obj.getDtnasc()+")";
		return sql;
	}

	@Override
	public String editar(Funcionario obj) {
		String sql = "UPDATE "+TABELA_NOME+" SET "
				+ "nome = '" + obj.getNome()+"', "
				+ "cpf = " + obj.getCpf()+", "
				+ "dtnasc = " + obj.getDtnasc()+" "
				+ "WHERE id = " + obj.getId();
		return sql;
	}

	@Override
	public String excluir(Funcionario obj) {
		String sql = "DELETE FROM " + TABELA_NOME + " WHERE id = "+obj.getId();
		return sql;
	}

	@Override
	public String buscaPorId(int id) {
		String sql = "SELECT id, nome, cpf, dtnasc WHERE id="+id;
		return sql;
	}

}
