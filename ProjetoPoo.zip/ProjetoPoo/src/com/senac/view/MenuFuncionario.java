package com.senac.view;

import javax.swing.JOptionPane;

import com.senac.DAO.FuncionarioDAO;
import com.senac.DAO.ProdutoDAO;
import com.senac.modelos.Funcionario;
import com.senac.modelos.Produto;

public class MenuFuncionario {
	private static final int MENU_CADASTRAR_FUNCIONARIO = 1;
	private static final int MENU_LISTAR_FUNCIONARIO = 2;
	private static final int MENU_EDITAR_FUNCIONARIO = 3;
	private static final int MENU_EXCLUIR_FUNCIONARIO = 4;
	private static final int MENU_PESQUISA_ID_FUNCIONARIO = 5;
	private static final int MENU_SAIR = 6;
	
	public static int showMenu(){
		String msg = MENU_CADASTRAR_FUNCIONARIO + " - Cadastrar funcionario\n"
				+ MENU_LISTAR_FUNCIONARIO + " - Listar funcionario\n"
				+ MENU_EDITAR_FUNCIONARIO + " - Editar funcionario\n"
				+ MENU_EXCLUIR_FUNCIONARIO + " - Excluir funcionario\n"
				+ MENU_PESQUISA_ID_FUNCIONARIO + " - Pesquisar por id\n"
				+ MENU_SAIR + " - Sair";
		return Painel.inputInt(msg);
	}
	
	
	public static void menuFuncionarios(){
		Funcionario p;
		FuncionarioDAO fDAO = new FuncionarioDAO();
		int opcao;
		do{
			opcao = showMenu();
			
			switch (opcao) {
				case MENU_CADASTRAR_FUNCIONARIO:
					p = putFuncionario();
					String res = fDAO.cadastrar(p);
					Painel.show(res);
					break;
					
				case MENU_EDITAR_FUNCIONARIO:
					Funcionario f = new Funcionario(94, "Ana", "099.463.586-31", "19/06/1994");
					p = editFunc(f);
					Painel.show(fDAO.editar(p));
					break;
				case MENU_EXCLUIR_FUNCIONARIO:
					Funcionario fExcluir = new Funcionario(94, "Ana", "099.463.586-31", "19/06/1994");
					int confirma = excluirFunc(fExcluir);
					if(confirma==0){
						Painel.show(fDAO.excluir(fExcluir));
					}
					break;
					
				case MENU_LISTAR_FUNCIONARIO:
					Painel.show(fDAO.listar());
					break;
					
				case MENU_PESQUISA_ID_FUNCIONARIO:
					int id = Painel.inputInt("Digite o c�digo do funcionario");
					Painel.show(fDAO.buscaPorId(id));
					break;
					
				case MENU_SAIR:
					Painel.show("Bye");
					break;
					
				default:
					Painel.show("Op��o inv�lida");
					break;
			}
		}while(opcao != MENU_SAIR);

	}
	
	public static Funcionario putFuncionario(){
		Funcionario f = new Funcionario();
		f.setId(Painel.inputInt("Digite o c�digo do funcionario"));
		f.setNome(Painel.input("Digite o nome do funcionario"));
		f.setCpf(Painel.input("Digite o cpf do funcionario"));
		f.setDtnasc(Painel.input("Digite a data de nascimento do funcionario"));
		return f;
	}
	
	public static Funcionario editFunc(Funcionario fn){
		Funcionario f = new Funcionario();
		f.setId(fn.getId());
		f.setNome(Painel.input("Digite o nome do funcionario", fn.getNome()));
		f.setCpf(Painel.input("Digite o cpf do funcionario", String.valueOf(fn.getCpf())));
		f.setDtnasc(Painel.input("Digite a data de nascimento do funcionario", String.valueOf(fn.getDtnasc())));
		return f;
	}
	
	public static int excluirFunc(Funcionario f){
		int escolha = JOptionPane.showConfirmDialog(null, "Deseja excluir o funcionario "+f.getNome()+"?");
		return escolha;
	}
}
