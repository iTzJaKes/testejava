package com.senac.modelos;

public class Funcionario {
	private int id;
	private String nome, cpf, dtnasc;
	
	public Funcionario() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Funcionario(int id, String nome, String cpf, String dtnasc) {
		super();
		this.id = id;
		this.nome = nome;
		this.cpf = cpf;
		this.dtnasc = dtnasc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getDtnasc() {
		return dtnasc;
	}

	public void setDtnasc(String dtnasc) {
		this.dtnasc = dtnasc;
	}

	@Override
	public String toString() {
		return "Funcionario [id=" + id + ", nome=" + nome + ", cpf=" + cpf + ", dtnasc=" + dtnasc + "]";
	}
	
	

}
